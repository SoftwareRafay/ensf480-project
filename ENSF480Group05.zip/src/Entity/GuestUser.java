/*
 * ENSF 480: Term Project - Movie App
 * 2024-11-09
 * Authors: Group 5-L01
 * Version: FINAL
 */

package Entity;

//A Guest User has all the attritbutes and methods of User
public class GuestUser extends User {

	public GuestUser() {
		super("Guest");
	}
}
